<?php
$module_name = 'planK_Planning';
$viewdefs [$module_name] = 
array (
  'DetailView' => 
  array (
    'templateMeta' => 
    array (
      'form' => 
      array (
        'buttons' => 
        array (
          0 => 'EDIT',
          1 => 'DUPLICATE',
          2 => 'DELETE',
          3 => 'FIND_DUPLICATES',
        ),
      ),
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
      'useTabs' => false,
      'tabDefs' => 
      array (
        'DEFAULT' => 
        array (
          'newTab' => false,
          'panelDefault' => 'expanded',
        ),
      ),
      'syncDetailEditViews' => true,
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            'name' => 'planning_name',
            'label' => 'LBL_PLANNING_NAME',
          ),
          1 => '',
        ),
        1 => 
        array (
          0 => 
          array (
            'name' => 'month',
            'studio' => 'visible',
            'label' => 'LBL_MONTH',
          ),
          1 => 
          array (
            'name' => 'year',
            'studio' => 'visible',
            'label' => 'LBL_YEAR',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'kp_total',
            'label' => 'LBL_KP_TOTAL',
          ),
          1 => '',
        ),
        3 => 
        array (
          0 => 
          array (
            'name' => 'project_total',
            'label' => 'LBL_PROJECT_TOTAL',
          ),
          1 => '',
        ),
        4 => 
        array (
          0 => 
          array (
            'name' => 'planned_sum',
            'label' => 'LBL_PLANNED_SUM',
          ),
          1 => '',
        ),
        5 => 
        array (
          0 => 
          array (
            'name' => 'year_plan',
            'studio' => 'visible',
            'label' => 'LBL_YEAR_PLAN',
          ),
        ),
      ),
    ),
  ),
);
